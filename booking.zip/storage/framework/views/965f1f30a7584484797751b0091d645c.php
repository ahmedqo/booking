<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(Core::lang('ar') ? 'rtl' : 'ltr'); ?>" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta property="og:type" content="website">
    <meta name="twitter:card" content="summary_large_image">
    <meta property="og:site_name" content="<?php echo e(__('Morocco Adventure City')); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta name="twitter:site" content="">
    <?php echo $__env->yieldContent('meta'); ?>
    <link rel="canonical" href="<?php echo e(url()->current()); ?>">
    <?php echo $__env->make('shared.base.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('styles'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body close>
    <section id="neo-page-cover">
        <img src="<?php echo e(asset('img/logo.png')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" alt="<?php echo e(env('APP_NAME')); ?> logo image"
            class="block w-20 animate-ping" width="916" height="516" />
    </section>
    <neo-wrapper class="flex flex-col">
        <?php echo $__env->make('shared.guest.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('shared.guest.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </neo-wrapper>
    <neo-toaster horisontal="end" vertical="start" class="full-size"></neo-toaster>
    <?php echo $__env->make('shared.base.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH P:\php\booking\resources\views/shared/guest/base.blade.php ENDPATH**/ ?>