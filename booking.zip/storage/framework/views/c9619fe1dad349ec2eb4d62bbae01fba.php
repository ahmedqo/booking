<section id="reservation" class="container mx-auto p-4 mt-6 mb-14">
    <h2 class="font-x-thin text-3xl text-x-black mb-6">
        <?php echo e(ucwords(__('take your place'))); ?>

    </h2>
    <form validate action="<?php echo e(route('actions.mail.send')); ?>" method="post"
        class="grid grid-cols-1 grid-rows-1 lg:grid-cols-2 gap-6">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="type" value="<?php echo e($type); ?>" />
        <div class="flex flex-col gap-px">
            <neo-textbox rules="required" name="name" label="<?php echo e(__('Name')); ?>"
                class="py-3 px-4 bg-transparent border border-x-shade"></neo-textbox>
            <span class="hidden text-red-500 text-sm font-x-thin">
                <?php echo e(__('The name field is required')); ?>

            </span>
        </div>
        <div class="flex flex-col gap-px">
            <neo-select search rules="required" name="country" label="<?php echo e(__('Country')); ?>"
                class="py-3 px-4 bg-transparent border border-x-shade">
                <?php $__currentLoopData = Core::nationsList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <neo-select-item value="<?php echo e($nation); ?>"><?php echo e(ucfirst(__($nation))); ?></neo-select-item>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </neo-select>
            <span class="hidden text-red-500 text-sm font-x-thin">
                <?php echo e(__('The country field is required')); ?>

            </span>
        </div>
        <div class="flex flex-col gap-px">
            <neo-textbox rules="email" type="email" name="email" label="<?php echo e(__('Email')); ?>"
                class="py-3 px-4 bg-transparent border border-x-shade"></neo-textbox>
            <span class="hidden text-red-500 text-sm font-x-thin">
                <?php echo e(__('The email field must be a valid email addressr')); ?>

            </span>
        </div>
        <div class="flex flex-col gap-px">
            <neo-textbox rules="phone" type="tel" name="phone" label="<?php echo e(__('Phone')); ?>"
                class="py-3 px-4 bg-transparent border border-x-shade"></neo-textbox>
            <span class="hidden text-red-500 text-sm font-x-thin">
                <?php echo e(__('The phone field must be a valid phone number')); ?>

            </span>
        </div>
        <div class="lg:col-span-2 flex flex-col gap-px">
            <neo-textarea rules="required" name="message" label="<?php echo e(__('Message')); ?>"
                class="py-3 px-4 bg-transparent border border-x-shade" rows="4"></neo-textarea>
            <span class="hidden text-red-500 text-sm font-x-thin">
                <?php echo e(__('The message field is required')); ?>

            </span>
        </div>
        <neo-button class="rounded-none px-10 py-3">
            <?php echo e(strtoupper(__('book now'))); ?>

        </neo-button>
    </form>
</section>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/validate.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH P:\php\booking\resources\views/shared/guest/reserve.blade.php ENDPATH**/ ?>