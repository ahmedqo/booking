<script src="<?php echo e(asset('js/neo/index.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
<script src="<?php echo e(asset('js/neo/plugins/guest.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
<script>
    Neo.load(function() {
        document.body.removeAttribute("close");
        document.body.querySelector("#neo-page-cover").remove();
        Neo.Helper.Theme.assign(
            "colors",
            "PRIME",
            getComputedStyle(document.documentElement)
            .getPropertyValue("--prime")
        );
        Neo.upgrade();
    });
</script>
<?php if(Session::has('message')): ?>
    <?php
        $messages = is_array(Session::get('message')) ? Session::get('message') : [Session::get('message')];
    ?>
    <script>
        Neo.load(function() {
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                Neo.Toaster.toast("<?php echo e($message); ?>", "<?php echo e(Session::get('type')); ?>");
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>
<?php endif; ?>
<?php /**PATH P:\php\booking\resources\views/shared/base/scripts.blade.php ENDPATH**/ ?>