<div class="aspect-[16/8] rounded-x-huge overflow-hidden relative flex flex-wrap items-center">
    <button id="ui-prev" aria-label="prev_arrow"
        class="flex items-center justify-center w-8 h-8 rounded-full absolute left-4 rtl:left-auto rtl:right-4 hover:bg-gray-900">
        <svg class="block w-5 h-5 pointer-events-none text-x-white" viewBox="0 -960 960 960" fill="currentColor">
            <path
                d="<?php echo e(Core::lang('ar') ? 'M584-412H114v-136h470L382-750l98-96 366 366-366 366-97-96 201-202Z' : 'm376-412 201 202-97 96-366-366 366-366 98 96-202 202h470v136H376Z'); ?>" />
        </svg>
    </button>
    <div id="ui-carousel" class="w-full">
        <ul>
            <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="w-full aspect-[16/8]">
                    <img src="<?php echo e($image); ?>" alt="<?php echo e($alt); ?> <?php echo e($loop->index + 1); ?>" loading="lazy"
                        class="block w-full h-full object-cover object-center" />
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <button id="ui-next" aria-label="next_arrow"
        class="flex items-center justify-center w-8 h-8 rounded-full absolute right-4 rtl:right-auto rtl:left-4 hover:bg-gray-900">
        <svg class="block w-5 h-5 pointer-events-none text-x-white" viewBox="0 -960 960 960" fill="currentColor">
            <path
                d="<?php echo e(Core::lang('ar') ? 'm376-412 201 202-97 96-366-366 366-366 98 96-202 202h470v136H376Z' : 'M584-412H114v-136h470L382-750l98-96 366 366-366 366-97-96 201-202Z'); ?>" />
        </svg>
    </button>
</div>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/slider.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH P:\php\booking\resources\views/shared/guest/slider.blade.php ENDPATH**/ ?>