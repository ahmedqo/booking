<?php
    $url = url()->current();
    $trips = Core::trips(isset($private));
    $trips = $trips
        ->reject(function ($trip) use ($url) {
            return $trip->url === $url;
        })
        ->random(2);
?>

<div class="flex flex-col gap-6">
    <h2 class="font-x-thin text-3xl text-x-black text-center">
        <?php echo e(ucwords(__('Recommended'))); ?>

    </h2>
    <ul class="grid grid-rows-1 grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-6">
        <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="w-full">
                <a href="<?php echo e($trip->url); ?>"
                    class="block rounded-x-huge overflow-hidden w-full aspect-[9/12] relative isolate">
                    <img src="<?php echo e($trip->image); ?>" alt="<?php echo e(pathinfo($trip->image, PATHINFO_FILENAME)); ?>" loading="lazy"
                        class="absolute w-full h-full inset-0 object-cover object-center z-[-1]">
                    <div class="absolute w-full h-full inset-0 flex items-end justify-center px-4 py-10">
                        <div class="flex flex-col items-center gap-4">
                            <h5
                                class="text-3xl font-x-thin text-x-white text-center p-2 px-4 bg-x-prime rounded-x-thin">
                                <?php echo e($trip->title); ?>

                            </h5>
                            <span class="block text-3xl font-x-thin text-x-white text-center">
                                <?php echo e($trip->price); ?> €
                            </span>
                        </div>
                    </div>
                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH P:\php\booking\resources\views/shared/guest/extra.blade.php ENDPATH**/ ?>